﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_2018
{
    public class Dulce : Producto
    {
        #region Constructor
        public Dulce(EMarca marca, string patente, ConsoleColor color) : base(patente, marca, color) { }
        #endregion

        #region Propiedades
        /// <summary>
        /// Los dulces tienen 80 calorías
        /// </summary>
        public override short CantidadCalorias
        {
            get
            {
                return 80;
            }
        }
        #endregion

        #region Metodos
        /// <summary>
        /// Devuelve los datos del objeto en formato string, utilizando la sobrecarga heredada.
        /// </summary>
        /// <returns></returns>
        public override string Mostrar()
        {
            string retorno;
            return retorno = (string)this;
        }
        #endregion
    }
}
