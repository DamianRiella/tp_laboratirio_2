using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesAbstractas
{
  public abstract class Universitario: Persona
  {
        #region Atributos
        private int legajo;
        #endregion

        #region Propiedades
        public int Legajo
        {
          get { return legajo; }
          set { legajo = value; }
        }
        #endregion

        #region Constructores
        public Universitario()
        {
          Apellido = "";
          Nombre = "";
          Nacionalidad = ENacionalidad.Argentino;
          DNI = 00000000;
          Legajo = 0;
        }

        public Universitario(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad)
                              : base(nombre, apellido, dni, nacionalidad)
        {
          Legajo = legajo;
        }
        #endregion

        #region Metodos
        protected virtual string MostrarDatos()
        {
                string retorno;
                StringBuilder sb = new StringBuilder();

                sb.AppendLine(this.ToString());
                sb.AppendLine(Convert.ToString(Legajo));

                return retorno = Convert.ToString(sb);
        }

        protected abstract string ParticiparEnClase();
        #endregion

        #region Sobrecargas
        public override bool Equals(object obj)
        {
            bool retorno=false;

            if(!(obj is null))
            {
                retorno = true;
            }
            return retorno;
        }

        public static bool operator ==(Universitario pg1, Universitario pg2)
        {
            bool retorno = false;

            if (pg1.DNI == pg2.DNI)
            {
                retorno = true;
            }
            return retorno;
        }

        public static bool operator !=(Universitario pg1, Universitario pg2)
        {
            return !(pg2 == pg1);
        }
        #endregion

    }
}
