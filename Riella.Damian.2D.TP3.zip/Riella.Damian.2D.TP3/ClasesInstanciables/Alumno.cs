﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;
using static ClasesInstanciables.Universidad;

namespace ClasesInstanciables
{
    public sealed class Alumno : Universitario
    {
        #region Enumerador
        public enum EEstadoCuenta
        {
            AlDia,
            Deudor,
            Becado
        }
        #endregion

        #region Atributos
        private EClases claseQueToma;
        private EEstadoCuenta estadoCuenta;
        #endregion

        #region Propiedades
        public EClases ClaseQueToma
        {
            get { return claseQueToma; }
            set { claseQueToma = value; }
        }

        public EEstadoCuenta EstadoCuenta
        {
            get { return estadoCuenta; }
            set { estadoCuenta = value; }
        }
        #endregion

        #region Constructores
        public Alumno()
        {
            claseQueToma = EClases.Programacion;
            estadoCuenta = EEstadoCuenta.AlDia;
        }

        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, EClases claseQueToma):
            base(id,nombre,apellido,dni,nacionalidad)
        {
            this.claseQueToma = claseQueToma;
        }

        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, EClases claseQueToma, EEstadoCuenta estadoCuenta) : this(id, nombre, apellido, dni, nacionalidad, claseQueToma)
        {
            this.EstadoCuenta = estadoCuenta;
        }
#endregion

        #region Metodos
        protected override string ParticiparEnClase()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("TOMA CLASE DE {0}", this.ClaseQueToma);

            return retorno = Convert.ToString(sb);

        }

        protected override string MostrarDatos()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.MostrarDatos());
            sb.AppendLine(Convert.ToString(claseQueToma));
            sb.AppendLine(Convert.ToString(estadoCuenta));

            return retorno = Convert.ToString(sb);
        }

        public new string ToString()
        {
            return this.MostrarDatos();
        }
        #endregion

        #region Sobrecargas
        public static bool operator ==(Alumno a, EClases clase)
        {
            bool retorno = false;

            if (a.ClaseQueToma == clase && a.EstadoCuenta!=EEstadoCuenta.Deudor)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Alumno a, EClases clase)
        {
            return !(a == clase);
        }
        #endregion

    }
}
