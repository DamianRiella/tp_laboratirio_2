﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Archivos;
using Exepciones;


namespace ClasesInstanciables
{
    public class Universidad
    {
        #region Enumerador
        public enum EClases
        {
            Programacion,
            Laboratorio,
            Legislacion,
            SPD
        }
        #endregion

        #region Atributos
        private List<Alumno> alumnos;
        private List<Profesor> profesores;
        private List<Jornada> jornadas;
        #endregion

        #region Propiedades
        public List<Alumno> Alumnos
        {
            get { return alumnos; }
            set { alumnos = value; }
        }

        public List<Profesor> Profesores
        {
            get { return profesores; }
            set { profesores = value; }
        }

        public List<Jornada> Jornadas
        {
            get { return jornadas; }
            set { jornadas = value; }
        }

        public Jornada this[int i]
        {
            get{return jornadas[i];}
            set{this[i] = value;}
        }
        #endregion

        #region Constructor
        public Universidad()
        {
            alumnos = new List<Alumno>();
            profesores = new List<Profesor>();
            jornadas = new List<Jornada>();
        }
        #endregion

        #region Metodos
        public Universidad Leer()
        {
            Xml<Universidad> xml = new Xml<Universidad>();
            Universidad g = new Universidad();
            string path = String.Format("{0}\\Universidad.xml", Environment.GetFolderPath(Environment.SpecialFolder.Desktop));
            xml.Leer(path, out g);
            return g;
        }
        public static bool Guardar(Universidad uni)
        {
            Xml<Universidad> xml = new Xml<Universidad>();
            bool ret = false;
            string path = String.Format("{0}\\Universidad.xml", Environment.GetFolderPath(Environment.SpecialFolder.Desktop));
            ret = xml.Guardar(path, uni);
            return ret;
        }
        #endregion

        #region Operadores
        public static bool operator !=(Universidad g, Alumno a)
        {
            return !(g == a);
        }
        public static bool operator !=(Universidad g, Profesor i)
        {
            return !(g == i);
        }
        public static Profesor operator !=(Universidad g, EClases clase)
        {
            foreach (Profesor item in g.profesores)
            {
                if (item != clase)
                    return item;
            }
            throw new SinProfesorException();
        }
        public static bool operator ==(Universidad g, Alumno a)
        {
            bool retorno = false;
            foreach (Alumno item in g.alumnos)
            {
                if (item.Legajo == a.Legajo)
                {
                    retorno= true;
                }
                   
            }
            return retorno;
        }
        public static bool operator ==(Universidad g, Profesor i)
        {
            bool retorno = false;
            foreach (Profesor item in g.profesores)
            {
                if (item.Legajo == i.Legajo)
                {
                    retorno = true;
                }
            }
            return retorno;
        }
        public static Profesor operator ==(Universidad g, EClases clase)
        {
            foreach (Profesor item in g.profesores)
            {
                if (item == clase)
                    return item;
            }
            throw new SinProfesorException();
        }
        public static Universidad operator +(Universidad g, Alumno a)
        {
            if (g != a)
            {
                g.alumnos.Add(a);
                return g;
            }
            throw new AlumnoRepetidoException();
        }
        public static Universidad operator +(Universidad g, Profesor i)
        {
            if (g != i)
            {
                g.profesores.Add(i);
            }
            return g;
        }
        public static Universidad operator +(Universidad g, EClases clase)
        {
            Jornada jornada = new Jornada(clase, g == clase);
            g.jornadas.Add(jornada);
            foreach (Alumno item in g.alumnos)
            {
                if (item == clase)
                {
                    jornada.Alumnos.Add(item);
                }
            }
            return g;
        }
        #endregion
    }
}
