﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ClasesInstanciables.Universidad;
using Archivos;

namespace ClasesInstanciables
{
    public class Jornada
    {
        #region Atributos
        private List<Alumno> alumnos;
        private EClases clase;
        private Profesor instructor;
        #endregion

        #region Propiedades
        public List<Alumno> Alumnos
        {
            get{ return alumnos; }
            set{alumnos = value; }
        }
       
        public EClases Clase
        { 
            get{ return clase;}
            set{ clase = value; }
        }

        public Profesor Instructor
        {
            get{ return instructor;}
            set{ instructor = value;}
        }
        #endregion

        #region Constructores
        private Jornada()
        {
            alumnos = new List<Alumno>();
        }

        public Jornada(EClases clase, Profesor instructor) : this()
        {
            this.clase = clase;
            this.instructor = instructor;
        }
        #endregion

        #region Metodos
        public static bool Guardar(Jornada jornada)
        {
            string path = String.Format("{0}\\Jornada.txt", Environment.GetFolderPath(Environment.SpecialFolder.Desktop));
            Texto texto = new Texto();
            return texto.Guardar(path, jornada.ToString());
        }

        public string Leer()
        {
            string datos;
            Texto texto = new Texto();
            string path = String.Format("{0}\\Jornada.txt", Environment.GetFolderPath(Environment.SpecialFolder.Desktop));
            texto.Leer(path, out datos);
            return datos;
        }

        public override string ToString()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(Instructor.ToString());
            sb.AppendLine(Convert.ToString(Clase));
            foreach (Alumno item in Alumnos)
            {
                sb.AppendLine(item.ToString());
            }
           
            return retorno = Convert.ToString(sb);
        }
        #endregion

        #region Sobrecarga
        public static bool operator ==(Jornada j, Alumno a)
        {
            bool retorno = false;

            if (a.ClaseQueToma == j.Clase)
            {
                retorno = true;
            }
            return retorno;
        }

        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }

        public static Jornada operator +(Jornada j, Alumno a)
        {
            foreach (Alumno item in j.Alumnos)
            {
                if (item.Legajo == a.Legajo)
                {
                    return j;
                }
            }
            j.Alumnos.Add(a);
            return j;
        }
        #endregion
    }
}
