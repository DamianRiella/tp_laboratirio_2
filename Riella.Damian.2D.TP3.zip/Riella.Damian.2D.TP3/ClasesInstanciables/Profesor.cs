﻿using EntidadesAbstractas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ClasesInstanciables.Universidad;

namespace ClasesInstanciables
{
    public sealed class Profesor : Universitario
    {
        #region Atributos
        private Queue<EClases> clasesDelDia;
        static Random random;
        #endregion

        #region Propiedades
        public Queue<EClases> ClaseDeDia
        {
            get { return clasesDelDia; }
            set { clasesDelDia = value; }
        }
        #endregion

        #region Constructores
        static Profesor()
        {
            random = new Random();
        }

        public Profesor() : base() { }

        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(id, nombre, apellido, dni, nacionalidad)
        {
            clasesDelDia = new Queue<EClases>();
            this._randomClases();
        }
        #endregion

        #region Metodos
        private void _randomClases()
        {
            clasesDelDia.Enqueue((Universidad.EClases)random.Next(5));
            System.Threading.Thread.Sleep(1000);
            clasesDelDia.Enqueue((Universidad.EClases)random.Next(4));
        }

        protected override string ParticiparEnClase()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("TOMA CLASE DE {0}", Convert.ToString(clasesDelDia.Dequeue()));

            return retorno = Convert.ToString(sb);
        }

        protected override string MostrarDatos()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.MostrarDatos());
            sb.AppendLine(this.ParticiparEnClase());

            return retorno = Convert.ToString(sb);
        }

        public override string ToString()
        {
            return this.MostrarDatos();
        }
        #endregion

        #region Sobrecargas
        public static bool operator ==(Profesor p, EClases clase)
        {
            bool retorno = false;
            foreach (EClases item in p.clasesDelDia)
            {
                if (item == clase)
                {
                    retorno = true;
                    break;
                }
            }
            return retorno;

        }

        public static bool operator !=(Profesor p, EClases clase)
        {
            return !(p == clase);
        }
        #endregion

    }
}
