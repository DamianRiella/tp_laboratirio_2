using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{

    public class Numero
    {
        #region Atributos
          private double numero;
        #endregion
       
        #region Propiedades
        /// <summary>
        /// Asigna un valor al atributo numero.
        /// </summary>
        public string SetNumero
        {
            set
            {
                numero = ValidarNumero(value);
            }
        }
        #endregion

        #region Constructores

        /// <summary>
        /// constructor que recibe un double y lo asigna como valor de un numero.
        /// </summary>
        /// <param name="numero"></param>
        public Numero(double numero)
        {
            this.numero = numero;
        }

        /// <summary>
        /// constructor que no recibe nada y asigna '0' como valor de un numero.
        /// </summary>
        public Numero() : this(0)
        {
        }

        /// <summary>
        /// constructor que recibe un string y lo asigna como valor de un numero.
        /// </summary>
        /// <param name="StrNumero"></param>
        public Numero(string strNumero)
        {
            this.SetNumero = strNumero;
        }
        #endregion

        #region Metodos

        /// <summary>sobrecarga de operador '+' para dos objetos de tipo "Numero". </summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns>Retorna el resultado de la suma.</returns>
        public static double operator +(Numero n1, Numero n2)
        {
        double Retorno = 0;
        Retorno = n1.numero + n2.numero;
        return Retorno;
        }



        /// <summary> sobrecarga de operador '-' para dos objetos de tipo "Numero". </summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns>Retorna el resultado de la resta. </returns>
        public static double operator -(Numero n1, Numero n2)
        {
        double Retorno = -1;
        Retorno = n1.numero - n2.numero;
        return Retorno;
        }



        /// <summary>sobrecarga de operador '*' para dos objetos de tipo "Numero".</summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns>Retorna el resultado de la multiplicacion.</returns>
        public static double operator *(Numero n1, Numero n2)
        {
        double Retorno = -1;
        Retorno = n1.numero * n2.numero;
        return Retorno;
        }



        /// <summary>sobrecarga de operador '/' para dos objetos de tipo "Numero"</summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns>Retorna el resultado de la divicion. </returns>
        public static double operator /(Numero n1, Numero n2)
        {
            double Retorno = -1;
            Retorno = n1.numero / n2.numero;
            return Retorno;
        }

   

        /// <summary>Comprueba que el valor recibido sea numerico.</summary>
        /// <param name="strNumero">Recibe un string</param>
        /// <returns>Retorna el valor recibido por parametro con formato double si esta todo ok, de lo contrario retorna 0.</returns>
        public static double ValidarNumero(string strNumero)
        {
            double resultado = 0;
            bool convers = double.TryParse(strNumero, out resultado);
            if (convers == true)
            {
            return resultado;
            }
            else
            {
            return resultado;
            }
        }


    
        /// <summary>Convierte el paretro binario a decimal.</summary>
        /// <param name="num">Parametro del tipo string.</param>
        /// <returns>Retorna el parametro convertido en decimal del tipo strig.</returns>
        public static string BinarioDecimal(string num)
        {
            string resultado = "Valor invalido";
            char[] array = num.ToCharArray();
            // Invertido pues los valores van incrementandose de derecha a izquierda: 16-8-4-2-1
            Array.Reverse(array);
            int suma = 0;
            double auxnum;

            if (double.TryParse(num, out auxnum) && auxnum > 0 && auxnum % 1 == 0)
            {
                for (int i = 0; i < array.Length; i++)
                {
                    if (array[i] == '1'|| array[i] == '0')
                    {
                        if(array[i] == '1')
                        // Usamos la potencia de 2, según la posición
                        suma += (int)Math.Pow(2, i);
                    }
                    /*else if (array[i] == '0')
                    {
                        continue;
                    }*/
                    else
                    {
                        return "Valor invalido";
                    }
                }

               resultado = suma.ToString();  
            }
            return resultado;
        }



        /// <summary>Convierte el paretro decimal a binario</summary>
        /// <param name="num">Parametro del tipo string.</param>
        /// <returns>Retorna el parametro convertido en binario del tipo strig.</returns>
        public static string DecimalBinario(string num)
            {
            int n = int.Parse(num);
            string bin = "", error = "Valor invalido";

            while (true)
            {
                if ((n % 2) == 1)
                {
                bin = "1" + bin;
                }
                else if ((n % 2 == 0))
                {
                bin = "0" + bin;
                }
                else
                {
                return error;
                }

                n /= 2;//Divido por dos al numero.

                if (n <= 0)
                {
                break;
                }
            }

            return bin;
            }



        /// <summary>Convierte el paretro decimal a binario reutilizando codigo mediante una llamada a otro metodo. </summary>
        /// <param name="num">Parametro del tipo double</param>
        /// <returns>Retorna el parametro convertido en binario del tipo double.</returns>
        public static string DecimalBinario(double num)
            {

                string n = "NULL", retorno = "Valor invalido";
                n = Convert.ToString(num);
                if(n!= "NULL")
                {
                retorno = Numero.DecimalBinario(n);
                }
                return retorno; ;
            }

        #endregion
    }
}
